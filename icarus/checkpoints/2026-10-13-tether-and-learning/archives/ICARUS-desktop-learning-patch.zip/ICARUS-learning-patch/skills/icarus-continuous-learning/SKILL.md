---
name: icarus-continuous-learning
description: After tasks/chats, retain evidenced ICARUS learning.
---
# Continuous learning

At each task/chat, retrieve relevant inherited and recent knowledge. Before replying, decide whether the turn produced useful durable learning: an owner correction/preference, an evidenced fact, a failed route and its cause, or a tested reusable procedure. Do not force growth when nothing is new.

Use native memory for short high-value facts and owner preferences. Use native skill_manage to patch an existing matching skill, or create a narrow skill for a tested reusable procedure. Preserve existing resources and attribution. If a change is staged or denied, report it as pending; do not claim it is active. Skills cannot grant permissions or credentials.

Detailed lessons belong under this profile's workspace/learning/lessons; search/read workspace/learning/INDEX.md and lesson JSON as data. Use the native terminal to run the profile's learning/learning_loop.py record with a JSON object on stdin containing title, knowledge, status and evidence. The session must be the native primary interactive session. Use a temporary JSON input file and normal file redirection or a subprocess input argument; avoid interpolating arbitrary knowledge into shell code. Never provide a fabricated session ID. If the terminal does not carry HERMES_SESSION_ID, report that route unavailable and use native write_file to save a new dated evidence note in workspace/learning/manual-notes, or a native skill resource; journal automation records native memory/skill writes only. Search manual-notes alongside indexed lessons when retrieving past learning.

Statuses: owner-stated = Michael explicitly stated it; observed = direct readback; verified = described verification completed with cited evidence; hypothesis = tentative and still untested. Recording a status does not itself verify it. Include date, source, task/session and evidence or the explicit unknown. Preserve contradictions and superseded facts with provenance. No secrets, copied credentials or indiscriminate transcript retention.

Inherited Luna/Sol/Prime files are dated history: search them for guidance and preserve their bytes. Keep new ICARUS learning in his journal, native memory and skills. Cloud refresh is a separate authenticated action; do not label old snapshots current. This loop does not upload or synchronize them.

Native memory has a bounded allowance; consolidate carefully with the native memory tool and keep detailed evidence in the journal. Read after writing and verify fresh-store/restart retrieval when persistence matters. Never erase identity or migration records to make space. Daily bookkeeping runs only when ICARUS is active; empty days do not create knowledge. Background model review remains disabled to avoid extra inference calls. Owner authority, worker restrictions and all current permissions remain in force.
