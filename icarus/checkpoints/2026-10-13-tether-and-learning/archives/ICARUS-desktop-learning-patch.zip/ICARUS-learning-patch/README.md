# Desktop ICARUS learning profile patch

Installed and read back on desktop on 12 October 2026. This package contains the new local hook and native skill. See the accompanying LEARNING-REPAIR-REPORT.md and evidence JSON files for exact scope and remaining checks.

Files relative to the active ICARUS desktop profile:

- learning/learning_loop.py
- skills/icarus-continuous-learning/SKILL.md

Existing native MEMORY.md was retained; a short pointer to the learning procedure was added through the native memory tool. Three attributed initial lesson records were saved in workspace/learning/lessons. Inherited source records were preserved.

The narrow configuration patch increases memory.memory_char_limit to 6000 and appends hooks without replacing existing governance hooks:

```yaml
hooks:
  pre_llm_call:
    - command: '"C:/Users/the1m/AppData/Local/Programs/Python/Python312/python.exe" -B "C:/Users/the1m/AppData/Local/hermes/profiles/icarus/learning/learning_loop.py"'
      timeout: 5
  post_tool_call:
    # Keep the existing governance entry first.
    - matcher: '^(memory|skill_manage)$'
      command: '"C:/Users/the1m/AppData/Local/Programs/Python/Python312/python.exe" -B "C:/Users/the1m/AppData/Local/hermes/profiles/icarus/learning/learning_loop.py"'
      timeout: 5
  on_session_end:
    - command: '"C:/Users/the1m/AppData/Local/Programs/Python/Python312/python.exe" -B "C:/Users/the1m/AppData/Local/hermes/profiles/icarus/learning/learning_loop.py"'
      timeout: 5
```

Paths above describe this installation; adapt to the actual profile/interpreter on another desktop. Do not paste this partial hooks block over existing configuration. Preserve the governance entries, their fail-closed setting, identity, provider, credentials and authority boundaries. Background model review remains disabled.

New agents/chats load these hooks. A live model learning turn remains unverified. This is not an Android phone or Tether deployment package.
