"""Profile-local learning reminders and journals; no network or inference calls."""
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import time
from datetime import datetime, timezone
from contextlib import closing, contextmanager


def stamp():
    return datetime.now(timezone.utc).isoformat()


def owned(root, relative):
    path = root / relative
    path.resolve().relative_to(root.resolve())
    if path.is_symlink():
        raise ValueError("Linked learning targets are refused")
    return path


def primary(root, session):
    if os.getenv("HERMES_DELEGATED_CHILD_CONTEXT") or os.getenv("HERMES_KANBAN_TASK"):
        return False
    if not isinstance(session, str) or not session:
        return False
    try:
        with closing(sqlite3.connect((root / "state.db").as_uri() + "?mode=ro", uri=True)) as db:
            origin = db.execute("SELECT source,created_source FROM sessions WHERE id=?", (session,)).fetchone()
        allowed = {"desktop", "cli", "tui", "oneshot"}
        return bool(origin and origin[0] in allowed and origin[1] in allowed)
    except sqlite3.Error:
        return False


def atomic_text(path, text):
    temporary = path.with_name(path.name + "." + str(os.getpid()) + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    try:
        for attempt in range(5):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 4:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        if temporary.exists():
            temporary.unlink()


@contextmanager
def connect(root):
    directory = owned(root, "workspace/learning")
    directory.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(owned(root, "workspace/learning/activity.sqlite"), timeout=4)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS events (
          id TEXT PRIMARY KEY, at TEXT, day TEXT, session TEXT, kind TEXT, detail TEXT);
        CREATE TABLE IF NOT EXISTS turns (
          session TEXT PRIMARY KEY, turn TEXT, ended INTEGER DEFAULT 0);
    """)
    try:
        with db:
            yield db
    finally:
        db.close()


def append_event(root, session, kind, detail, identity):
    now = stamp()
    with connect(root) as db:
        db.execute("INSERT OR IGNORE INTO events VALUES(?,?,?,?,?,?)",
                   (identity, now, now[:10], session, kind, json.dumps(detail, sort_keys=True)))


def summary(root):
    directory = owned(root, "workspace/learning")
    with connect(root) as db:
        rows = db.execute("SELECT day,kind,COUNT(*) FROM events GROUP BY day,kind ORDER BY day DESC,kind").fetchall()
    lines = ["# ICARUS learning activity", "", "UTC dates. Events prove recording activity, not independent factual verification.",
             "No transcripts, credentials or tool-output text are stored in this index.", "",
             "| Day | Event | Count |", "|---|---|---|"]
    lines.extend(f"| {day} | {kind} | {count} |" for day, kind, count in rows)
    lines.extend(["", "## Knowledge records", "", "Search lessons/*.json; status and evidence accompany each lesson.",
                  "Inherited records remain at ../../generational-memory/INDEX.md (dated source snapshots)."])
    # Store machine metadata only; lesson text is retrieved explicitly as data.
    lessons = owned(root, "workspace/learning/lessons")
    if lessons.exists():
        for lesson in sorted(lessons.glob("*.json")):
            lesson.resolve().relative_to(root.resolve())
            try:
                item = json.loads(lesson.read_text(encoding="utf-8"))
                status, recorded = item['status'], item['recorded_at']
            except (OSError, json.JSONDecodeError, KeyError, TypeError):
                lines.append(f"- {lesson.name}: UNREADABLE OR INCOMPLETE; review this record.")
                continue
            lines.append(f"- {lesson.name}: status={status}; recorded={recorded}")
    atomic_text(directory / "INDEX.md", "\n".join(lines) + "\n")


def validate_lesson(item):
    if set(item) != {"title", "knowledge", "status", "evidence"}:
        raise ValueError("Required fields: title, knowledge, status, evidence")
    if item["status"] not in {"owner-stated", "observed", "verified", "hypothesis"}:
        raise ValueError("Unknown knowledge status")
    if any(not isinstance(v, str) or not v.strip() or len(v) > 5000 for v in item.values()):
        raise ValueError("Fields must be nonempty bounded strings")
    text = json.dumps(item)
    if re.search(r"(?i)(bearer\s+[A-Za-z0-9._-]{12,}|(?:api[_ -]?key|password|secret|access[_ -]?token)\s*[:=]\s*\S+|sk-[A-Za-z0-9_-]{16,})", text):
        raise ValueError("Potential credential: redact before saving")


def record_lesson(root, item, origin):
    validate_lesson(item)
    canonical = json.dumps(item, sort_keys=True, ensure_ascii=False)
    identity = hashlib.sha256(canonical.encode()).hexdigest()
    directory = owned(root, "workspace/learning/lessons")
    directory.mkdir(parents=True, exist_ok=True)
    path = owned(root, f"workspace/learning/lessons/{identity}.json")
    record = {**item, "id": identity, "recorded_at": stamp(), "recorded_by": origin,
              "verification_note": "Status is attributed to the recorder; this writer does not independently verify claims."}
    try:
        with path.open("x", encoding="utf-8") as handle:
            handle.write(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
    except FileExistsError:
        return {"success": True, "duplicate": True, "path": str(path)}
    append_event(root, origin, "lesson_recorded", {"lesson_id": identity, "status": item["status"]}, "lesson:" + identity)
    summary(root)
    return {"success": True, "duplicate": False, "path": str(path)}


def handle(root, payload):
    session = payload.get("session_id", "")
    if not primary(root, session):
        return {}
    event = payload.get("hook_event_name")
    extra = payload.get("extra") or {}
    if event == "pre_llm_call":
        turn = hashlib.sha256(os.urandom(32)).hexdigest()[:24]
        with connect(root) as db:
            db.execute("INSERT OR REPLACE INTO turns VALUES(?,?,0)", (session, turn))
        append_event(root, session, "learning_review_due", {}, "turn:" + turn)
        summary(root)
        inherited = root / "generational-memory/INDEX.md"
        knowledge = root / "workspace/learning/INDEX.md"
        skill = root / "skills/icarus-continuous-learning/SKILL.md"
        return {"context": (
            "ICARUS learning reminder (owner-authorized profile procedure): retrieve relevant inherited lessons from "
            f"{inherited} and current knowledge from {knowledge}. Before finishing this task/chat, retain any useful "
            "new owner correction, preference, evidenced fact or reusable procedure. Use native memory for concise "
            "facts, skill_manage for tested procedures, and the local lesson journal for detailed evidence. Read "
            f"{skill} when saving or revising learning. Deduplicate; distinguish owner-stated, observed, verified and "
            "hypothesis. A tool success proves a write, not the truth of its content. When nothing useful is new, "
            "save nothing. No extra paid review, permission changes, identity edits or invented daily lessons. "
            "If saving fails, report it accurately and keep the response moving. Daily bookkeeping is automatic "
            "during active chats, not a promise of unattended research or cloud synchronization.")}
    if event == "post_tool_call":
        tool = payload.get("tool_name")
        args = payload.get("tool_input") or {}
        if tool not in {"memory", "skill_manage"}:
            return {}
        result = extra.get("result")
        if isinstance(result, str):
            try:
                result = json.loads(result)
            except json.JSONDecodeError:
                return {}
        if not isinstance(result, dict) or result.get("success") is not True:
            return {}
        # Success=False, staged approvals and reads do not count as learning writes.
        if any(result.get(k) for k in ("pending", "staged", "approval_required")):
            return {}
        action = args.get("action")
        operations = args.get("operations")
        if action not in {"add", "replace", "remove", "create", "patch", "edit", "write_file"} and not operations:
            return {}
        call = extra.get("tool_call_id")
        if not isinstance(call, str) or not call:
            return {}
        digest = hashlib.sha256(json.dumps(args, sort_keys=True).encode()).hexdigest()
        append_event(root, session, "native_" + tool + "_write", {"action": action or "batch", "arguments_sha256": digest},
                     "call:" + session + ":" + call)
        summary(root)
    elif event == "on_session_end":
        with connect(root) as db:
            row = db.execute("SELECT turn,ended FROM turns WHERE session=?", (session,)).fetchone()
            if row and not row[1]:
                db.execute("UPDATE turns SET ended=1 WHERE session=?", (session,))
        if row:
            append_event(root, session, "turn_finished" if extra.get("completed") and not extra.get("interrupted") else "turn_incomplete",
                         {}, "end:" + row[0])
            summary(root)
    return {}


def main():
    root = Path(__file__).resolve().parent.parent
    configured_home = os.getenv("HERMES_HOME")
    if configured_home and Path(configured_home).resolve() != root:
        raise PermissionError("The hook belongs to a different profile")
    if len(sys.argv) == 2 and sys.argv[1] == "record":
        session = os.getenv("HERMES_SESSION_ID", "")
        if not primary(root, session):
            raise PermissionError("A native primary interactive session is required")
        result = record_lesson(root, json.load(sys.stdin), session)
    elif len(sys.argv) == 1:
        result = handle(root, json.load(sys.stdin))
    else:
        raise ValueError("Use the hook protocol, or record with a JSON object on stdin")
    print(json.dumps(result))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"success": False, "error": str(exc)}))
        sys.exit(1)
